

<?php $__env->startSection('title', 'Percakapan - Pesan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex align-items-center mb-4">
        <a href="<?php echo e(route('messages.index')); ?>" class="btn btn-outline-secondary me-3">
            <i class="fas fa-arrow-left me-2"></i>Kembali
        </a>
        <h2 class="mb-0">
            <i class="fas fa-comment me-2"></i>Chat dengan <?php echo e($otherUser->name); ?>

        </h2>
    </div>

    <div class="card card-modern" style="height: 500px; overflow-y: auto;">
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-3 <?php echo e($message->from_user_id === Auth::id() ? 'text-end' : ''); ?>">
                    <div class="d-inline-block p-3 rounded"
                         style="max-width: 70%; background-color: <?php echo e($message->from_user_id === Auth::id() ? '#007bff' : '#e9ecef'); ?>; color: <?php echo e($message->from_user_id === Auth::id() ? 'white' : 'black'); ?>;">
                        <?php if($message->type !== 'general'): ?>
                            <span class="badge" style="background-color: <?php echo e($message->type === 'update_request' ? '#ff6b6b' : '#4c6ef5'); ?>">
                                <?php echo e(ucfirst(str_replace('_', ' ', $message->type))); ?>

                            </span>
                            <hr class="my-2">
                        <?php endif; ?>
                        <p class="mb-0"><?php echo e($message->message); ?></p>
                        <small class="d-block mt-2" style="opacity: 0.8;"><?php echo e($message->created_at->format('H:i')); ?></small>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-muted">Belum ada percakapan.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card card-modern mt-3">
        <div class="card-body">
            <form action="<?php echo e(route('messages.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="to_user_id" value="<?php echo e($otherUser->id); ?>">
                <div class="input-group">
                    <textarea name="message" class="form-control" placeholder="Ketik pesan Anda..." rows="3" required></textarea>
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-paper-plane me-2"></i>Kirim
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .card-modern {
        border: none;
        border-radius: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\marketplace-desain\resources\views/messages/conversation.blade.php ENDPATH**/ ?>