

<?php $__env->startSection('title', 'Admin Dashboard - DesignHub'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2 class="mb-0">Admin Dashboard</h2>
        <div>
            <a href="<?php echo e(route('admin.services')); ?>" class="btn btn-outline-secondary me-2">Manage Services</a>
            <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-outline-secondary me-2">Manage Users</a>
            <a href="<?php echo e(route('admin.orders')); ?>" class="btn btn-primary">Orders</a>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-3">
        <div class="card-modern p-4 text-center">
            <h6 class="text-muted">Total Users</h6>
            <h2 class="mt-2"><?php echo e($totalUsers ?? 0); ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern p-4 text-center">
            <h6 class="text-muted">Total Orders</h6>
            <h2 class="mt-2"><?php echo e($totalOrders ?? 0); ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern p-4 text-center">
            <h6 class="text-muted">Approved Services</h6>
            <h2 class="mt-2"><?php echo e($approvedServices->count() ?? 0); ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern p-4 text-center">
            <h6 class="text-muted">Pending Services</h6>
            <h2 class="mt-2 text-warning"><?php echo e($pendingServices->count() ?? 0); ?></h2>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern p-4 text-center">
            <h6 class="text-muted">Pending Updates</h6>
            <h2 class="mt-2 text-info"><?php echo e($pendingUpdates->count() ?? 0); ?></h2>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card-modern p-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">Recent Pending Services</h5>
                <small class="text-muted">Latest submissions by desainer</small>
            </div>

            <?php if($pendingServices->isEmpty()): ?>
                <div class="p-4 text-center text-muted">Tidak ada layanan yang menunggu persetujuan.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Designer</th>
                                <th>Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($s->id); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if($s->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $s->image)); ?>" alt="<?php echo e($s->title); ?>" class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light rounded me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                            <span><?php echo e(Str::limit($s->title, 30)); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo e($s->designer->name ?? '—'); ?></td>
                                    <td>Rp <?php echo e(number_format($s->price,0,',','.')); ?></td>
                                    <td><span class="badge bg-warning text-dark"><?php echo e(ucfirst($s->status)); ?></span></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('admin.services.approve', $s->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success me-1">Approve</button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('admin.services.reject', $s->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-danger">Reject</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card-modern p-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0">
                    <i class="fas fa-edit me-2"></i>Pending Service Updates
                </h5>
                <small class="text-muted">Update requests from desainer</small>
            </div>

            <?php if($pendingUpdates->isEmpty()): ?>
                <div class="p-4 text-center text-muted">Tidak ada update yang menunggu persetujuan.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Designer</th>
                                <th>Current Price</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendingUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($s->id); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if($s->image): ?>
                                                <img src="<?php echo e(asset('storage/' . $s->image)); ?>" alt="<?php echo e($s->title); ?>" class="rounded me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light rounded me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                            <span><?php echo e(Str::limit($s->title, 30)); ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo e($s->designer->name ?? '—'); ?></td>
                                    <td>Rp <?php echo e(number_format($s->price,0,',','.')); ?></td>
                                    <td><span class="badge bg-info">Update Pending</span></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('admin.services.approve-update', $s->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-success me-1">Approve Update</button>
                                        </form>
                                        <form method="POST" action="<?php echo e(route('admin.services.reject-update', $s->id)); ?>" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-warning">Reject Update</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\marketplace-desain\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>