

<?php $__env->startSection('title', 'Kelola Jasa - Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-3 col-lg-2 px-0">
			<div class="card-modern sidebar-admin">
				<div class="card-body p-4">
					<h5 class="mb-4">
						<i class="fas fa-cog me-2"></i>Admin Panel
					</h5>
					<nav class="nav flex-column">
						<a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
						<a class="nav-link active" href="<?php echo e(route('admin.services')); ?>">Kelola Jasa</a>
						<a class="nav-link" href="<?php echo e(route('admin.users')); ?>">Kelola User</a>
						<a class="nav-link" href="<?php echo e(route('admin.orders')); ?>">Kelola Order</a>
					</nav>
				</div>
			</div>
		</div>

		<div class="col-md-9 col-lg-10">
			<div class="d-flex justify-content-between align-items-center mb-4">
				<h2 class="mb-0"><i class="fas fa-palette me-2"></i>Kelola Jasa</h2>
				<a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-modern btn-primary">
					<i class="fas fa-plus me-2"></i>Tambahkan Jasa
				</a>
			</div>

			<?php if(session('success')): ?>
				<div class="alert alert-success"><?php echo e(session('success')); ?></div>
			<?php endif; ?>

			<div class="card card-modern">
				<div class="card-header">
					<h5 class="mb-0">Daftar Layanan</h5>
				</div>
				<div class="card-body">
					<div class="table-responsive">
						<table class="table table-hover align-middle">
							<thead class="table-light">
								<tr>
									<th>ID</th>
									<th>Judul</th>
									<th>Desainer</th>
									<th>Harga</th>
									<th>Status</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td><?php echo e($s->id); ?></td>
									<td><?php echo e($s->title); ?></td>
									<td><?php echo e($s->designer->name ?? '-'); ?></td>
									<td>Rp <?php echo e(number_format($s->price,0,',','.')); ?></td>
									<td>
										<span class="badge ">
											<?php echo e(ucfirst($s->status)); ?>

										</span>
									</td>
									<td>
										<div class="btn-group" role="group">
											<a href="<?php echo e(route('admin.services.edit', $s->id)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
											<?php if($s->status !== 'approved'): ?>
												<form action="<?php echo e(route('admin.services.approve', $s->id)); ?>" method="POST" class="d-inline">
													<?php echo csrf_field(); ?>
													<button class="btn btn-sm btn-success">Approve</button>
												</form>
											<?php endif; ?>

											<?php if($s->status !== 'rejected'): ?>
												<form action="<?php echo e(route('admin.services.reject', $s->id)); ?>" method="POST" class="d-inline">
													<?php echo csrf_field(); ?>
													<button class="btn btn-sm btn-danger">Reject</button>
												</form>
											<?php endif; ?>

											<form action="<?php echo e(route('admin.services.destroy', $s->id)); ?>" method="POST" class="d-inline">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<button class="btn btn-sm btn-outline-danger" onclick="return confirm('Yakin ingin menghapus jasa ini?')">Hapus</button>
											</form>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="6" class="text-center py-4">Belum ada layanan</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<style>
.sidebar-admin { min-height: calc(100vh - 76px); border-radius: 0; border-right: 1px solid rgba(0,0,0,0.06); }
.card-modern { border-radius: 12px; }
</style>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\marketplace-desain\resources\views/admin/services/index.blade.php ENDPATH**/ ?>